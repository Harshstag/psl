public interface Stall {
	abstract void display();
}
